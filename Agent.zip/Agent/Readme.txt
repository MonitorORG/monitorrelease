前提条件：
启动环境需要Java 1.7运行环境, 如果没安装，可以从下面链接中下载对应版本进行安装：
http://www.oracle.com/technetwork/java/javase/downloads/java-archive-downloads-javase7-521261.html

启动程序：
解压缩程序后，点击startup.bat运行即可。
